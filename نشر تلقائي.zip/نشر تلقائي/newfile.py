import requests
import subprocess
import tempfile
from urllib.parse import urlparse
import time
import os

def run_python_files_from_github(repo_url, max_retries=5, delay=10):
    retry_count = 0
    while retry_count < max_retries:
        try:
            # الحصول على محتويات المستودع عبر GitHub API
            parsed_url = urlparse(repo_url)
            path_parts = parsed_url.path.strip('/').split('/')
            
            if len(path_parts) < 2:
                print("رابط المستودع غير صحيح")
                return
            
            owner, repo = path_parts[:2]
            api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/"
            
            response = requests.get(api_url)
            
            # التحقق من حالة الاستجابة (خاصةً خطأ 429)
            if response.status_code == 429:
                retry_after = int(response.headers.get('Retry-After', delay))
                print(f"تم تجاوز معدل الطلبات (429). إعادة المحاولة بعد {retry_after} ثانية...")
                time.sleep(retry_after)
                retry_count += 1
                continue
            
            response.raise_for_status()  # يرفع استثناء لأي خطأ آخر
            
            contents = response.json()
            
            for item in contents:
                if item['name'].endswith('.py'):  # تشغيل ملفات بايثون فقط
                    print(f"\nجارٍ تشغيل ملف: {item['name']}")
                    
                    # جلب محتوى الملف
                    file_content = requests.get(item['download_url']).text
                    
                    # إنشاء ملف مؤقت وتشغيله
                    with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_file:
                        temp_file.write(file_content.encode('utf-8'))
                        temp_file_path = temp_file.name
                    
                    # تشغيل الملف باستخدام مترجم بايثون
                    result = subprocess.run(['python', temp_file_path], 
                                          capture_output=True, 
                                          text=True)
                    
                    # عرض النتائج
                    print("الإخراج:")
                    print(result.stdout)
                    if result.stderr:
                        print("الأخطاء:")
                        print(result.stderr)
                    
                    # حذف الملف المؤقت
                    os.unlink(temp_file_path)
            
            # إذا نجحت جميع الملفات، نخرج من حلقة إعادة المحاولة
            break
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                retry_after = int(e.response.headers.get('Retry-After', delay))
                print(f"حدث خطأ 429 (Too Many Requests). إعادة المحاولة بعد {retry_after} ثانية...")
                time.sleep(retry_after)
                retry_count += 1
            else:
                print(f"حدث خطأ HTTP: {str(e)}")
                retry_count += 1
                
        except Exception as e:
            print(f"حدث خطأ غير متوقع: {str(e)}")
            retry_count += 1
            
        if retry_count < max_retries:
            print(f"المحاولة القادمة ({retry_count + 1}/{max_retries})...")
            time.sleep(delay)
        else:
            print("تم الوصول إلى الحد الأقصى للمحاولات. إعادة تشغيل السورس...")
            # إعادة تشغيل السورس عن طريق استدعاء الدالة مرة أخرى
            run_python_files_from_github(repo_url, max_retries, delay)

# مثال للاستخدام
repo_url = "https://github.com/alialhasanywow/autobostnew.git"
run_python_files_from_github(repo_url)