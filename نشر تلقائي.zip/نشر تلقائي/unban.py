import requests

cookies = {
    'datr': 'oy6SaIEQlST6wxdR4YcaONJR',
    'ps_l': '1',
    'ps_n': '1',
    'm_pixel_ratio': '2.75',
    'fr': '05jKup5uAREUjnwCB..Boki6j..AAA.0.0.BoliPx.AWdZc2P7hmpyG6Rx27e1wj6PEws',
    'wd': '1036x1939',
}

headers = {
    'authority': 'web.facebook.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'datr=oy6SaIEQlST6wxdR4YcaONJR; ps_l=1; ps_n=1; m_pixel_ratio=2.75; fr=05jKup5uAREUjnwCB..Boki6j..AAA.0.0.BoliPx.AWdZc2P7hmpyG6Rx27e1wj6PEws; wd=1036x1939',
    'origin': 'https://web.facebook.com',
    'referer': 'https://web.facebook.com/help/contact/507270721277573/?wtsid=rdr_0qzGBAIITAuSRlXDO&_rdc=1&_rdr',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    'x-asbd-id': '359341',
    'x-fb-lsd': 'AVonoHkLdN0',
}

data = 'jazoest=2964&lsd=AVonoHkLdN0&Field913808139999102=Ali%20abd%20alrahman%20abd&type_of_account_input=instagram&instagram_problem_options=personal_account&something_else_context=&your_account_options=my_account&someone_else_name1=&hacked_yes_no=no&email_input=officialsequal%40gmail.com&user_name_input=awxlt&refID=&support_form_id=507270721277573&support_form_locale_id=ar_AR&support_form_hidden_fields=%7B%22801376801088024%22%3Afalse%2C%22838633380508728%22%3Afalse%2C%22685516229426276%22%3Atrue%2C%221354273622009715%22%3Atrue%2C%22680047607107393%22%3Afalse%2C%222381511141997365%22%3Afalse%2C%22884619342708129%22%3Afalse%2C%222649730538492688%22%3Atrue%2C%221707478336298755%22%3Atrue%2C%22636721034666279%22%3Afalse%2C%22689322235693357%22%3Afalse%2C%22444925861138376%22%3Atrue%2C%223258911281089079%22%3Afalse%7D&support_form_fact_false_fields=[]&__user=0&__a=1&__req=7&__hs=20308.BP%3ADEFAULT.2.0...0&dpr=1&__ccg=GOOD&__rev=1025671648&__s=zt5vzr%3Awf89ox%3Ar9mtzr&__hsi=7536250549180318073&__dyn=7xe6E5aQ1PyUbFp41twpUnwgU6C7UW8xi642-7E2vwXw5ux60Vo1upE4W0OE3nwaq1xwEwt81s8hwnU1e42C1Fw5uwtU1083mwaS0zE5W09yw4vwbS1Lw7Jw7zwtU5K0UE&__hsdp=gH2W4hy3gBKbRh1p42qjK9yqtau0GorCwIw4Cw34o26wWwMw4wwfWh09ebzA5o710xG530xg7213w9q1Go&__hblp=0Vwae6o2kw53wiU18E1UUswaG04rUG0SU0EC1Dw0H6wNRw0RKwn82Uw3G5z8K0KETho0pZw&__spin_r=1025671648&__spin_b=trunk&__spin_t=1754670066'

response = requests.post('https://web.facebook.com/ajax/help/contact/submit/page', cookies=cookies, headers=headers, data=data)
print(response.text)