import telethon
from telethon import TelegramClient, events
import asyncio
import os

ACCOUNTS = [
    
    {"name": "session", "app_id": "15992426", "api_hash": "e32ed9721a2d3cddc3c080bd4c9e1346"},

]

auto_posting_tasks = {}

class AccountManager:
    def __init__(self, account_info, account_num):
        self.account_info = account_info
        self.account_num = account_num
        self.client = TelegramClient(account_info["name"], account_info["app_id"], account_info["api_hash"])
        self.running = False
        
    async def initialize(self):
        try:
            await self.client.start()
            self.setup_handlers()
            self.running = True
            return True
        except Exception:
            return False
    
    def setup_handlers(self):
        @self.client.on(events.NewMessage(outgoing=True, pattern=r'^s (\d+) (\d+)$'))
        async def swing(event):
            try:
                if event.is_reply:
                    parts = event.text.split()
                    if len(parts) < 3:
                        await event.edit("❌ صيغة خاطئة. استخدم: s [الثواني] [العدد]")
                        return
                    
                    delay = int(parts[1])
                    count = int(parts[2])
                    chat_id = event.chat_id
                    message = await event.get_reply_message()
                    
                    task_id = f"{self.account_num}_{chat_id}"
                    auto_posting_tasks[task_id] = True
                    
                    await event.edit(f"⏳ بدء النشر ({count} مرة كل {delay} ثانية)")
                    
                    sent_count = 0
                    for i in range(count):
                        if not auto_posting_tasks.get(task_id, False):
                            break
                            
                        await self.client.send_message(chat_id, message)
                        sent_count += 1
                        
                        if i < count - 1:
                            await asyncio.sleep(delay)
                    
                    if auto_posting_tasks.get(task_id, False):
                        await event.edit(f"✅ تم إكمال النشر ({sent_count}/{count})")
                        await self.client.send_message("me", f"تم النشر في: {chat_id} - الحساب {self.account_num}")
                    else:
                        await event.edit(f"⏹️ تم إيقاف النشر ({sent_count}/{count})")
                    
                    auto_posting_tasks[task_id] = False
                else:
                    await event.edit("❌ يجب الرد على الرسالة")
            except Exception as e:
                await event.edit(f"❌ خطأ: {str(e)}")
                auto_posting_tasks.pop(f"{self.account_num}_{event.chat_id}", None)
        
        @self.client.on(events.NewMessage(outgoing=True, pattern=r'^\.ن0$'))
        async def stop_auto_posting(event):
            try:
                chat_id = event.chat_id
                task_id = f"{self.account_num}_{chat_id}"
                if auto_posting_tasks.get(task_id, False):
                    auto_posting_tasks[task_id] = False
                    await event.edit("✅ تم إيقاف النشر التلقائي")
                else:
                    await event.edit("⚠️ لا يوجد نشر تلقائي نشط")
            except Exception:
                await event.edit("❌ خطأ في الإيقاف")
        
        @self.client.on(events.NewMessage(outgoing=True, pattern=r'^sg (\d+) (\d+) (.+)$'))
        async def auto_post_to_channel(event):
            try:
                if event.is_reply:
                    parts = event.text.split()
                    if len(parts) < 4:
                        await event.edit("❌ صيغة خاطئة. استخدم: sg [الثواني] [العدد] [رابط القناة]")
                        return
                    
                    delay = int(parts[1])
                    count = int(parts[2])
                    channel_link = parts[3]
                    replied_msg = await event.get_reply_message()
                    
                    try:
                        channel_entity = await self.client.get_entity(channel_link)
                    except Exception:
                        await event.edit("❌ خطأ في العثور على القناة")
                        return
                    
                    task_id = f"{self.account_num}_channel_{channel_entity.id}"
                    auto_posting_tasks[task_id] = True
                    
                    await event.edit(f"⏳ بدء النشر في {getattr(channel_entity, 'title', channel_link)}")
                    
                    success_count = 0
                    for i in range(count):
                        if not auto_posting_tasks.get(task_id, False):
                            break
                            
                        try:
                            await self.client.send_message(entity=channel_entity, message=replied_msg)
                            success_count += 1
                            if i < count - 1:
                                await asyncio.sleep(delay)
                        except Exception as e:
                            await asyncio.sleep(5)
                    
                    result_msg = f"✅ تم الانتهاء\n✅ النجاح: {success_count}\n❌ الفشل: {count - success_count}"
                    await event.edit(result_msg)
                    auto_posting_tasks[task_id] = False
                else:
                    await event.edit("❌ يجب الرد على الرسالة")
            except Exception as e:
                await event.edit(f"❌ خطأ: {str(e)}")
                auto_posting_tasks.pop(f"{self.account_num}_channel_{getattr(channel_entity, 'id', '')}", None)
        
        @self.client.on(events.NewMessage(incoming=True))
        async def track_replies(event):
            if event.is_private or not event.is_reply:
                return
                
            try:
                replied_msg = await event.get_reply_message()
                if replied_msg and replied_msg.sender_id == self.client.uid:
                    sender = await event.get_sender()
                    sender_name = f"{getattr(sender, 'first_name', '')} {getattr(sender, 'last_name', '')}".strip() or getattr(sender, 'title', 'Unknown')
                    
                    chat = await event.get_chat()
                    chat_title = getattr(chat, 'title', 'Unknown Group')
                    
                    msg_text = event.text or "وسائط (صورة/ملف/إلخ)"
                    msg_link = f"https://t.me/c/{event.chat.id}/{event.id}"
                    
                    formatted_msg = f"""_____
المرسل ; "{sender_name}"
المحتوى ; "{msg_text}"
رابط الرسالة ; "{msg_link}"
المجموعة ; "{chat_title}"
"tg://user?id={event.sender_id}"
_____"""
                    
                    await self.client.send_message('me', formatted_msg)
            except Exception:
                pass
    
    async def run(self):
        while True:
            try:
                if not self.running:
                    success = await self.initialize()
                    if not success:
                        await asyncio.sleep(60)
                        continue
                await self.client.run_until_disconnected()
            except Exception:
                self.running = False
                await asyncio.sleep(30)
            self.running = False
            await asyncio.sleep(10)

async def main():
    account_managers = []
    for i, acc in enumerate(ACCOUNTS, 1):
        manager = AccountManager(acc, i)
        account_managers.append(manager)
    await asyncio.gather(*[manager.run() for manager in account_managers])

if __name__ == "__main__":
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    finally:
        loop.close()